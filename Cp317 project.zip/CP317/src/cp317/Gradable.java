package cp317;

public interface Gradable {
	double getFinalGrade();

	String getStudentID();
}
